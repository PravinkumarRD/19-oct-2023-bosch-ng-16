import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from "rxjs";
import { ActivatedRoute, Router } from "@angular/router";

import { AuthResponse } from "../../models/auth-response";
import { User } from "../../models/user";

import { SecurityService } from "../../services/security.service";

@Component({
  selector: 'bosch-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  constructor(private _activatedRoute: ActivatedRoute, private _securityService: SecurityService, private _router: Router) {

  }

  private _securityServiceSubscription: Subscription;
  title: string = "Bosch India - Authentication!";
  user: User = new User();
  authResponse: AuthResponse;
  errorMessage: string = "";
  private returnUrl: string;
  ngOnInit(): void {
    this.returnUrl = this._activatedRoute.snapshot.queryParams['returnurl'];
  }

  authenticateCredentials(): void {
    this._securityServiceSubscription = this._securityService.checkUserCredentials(this.user).subscribe({
      next: response => {
        if (response.success === true) {
          sessionStorage.setItem('role', response.role);
          sessionStorage.setItem('token', response.token);
          if (this.returnUrl) {
            this._router.navigate([this.returnUrl]);
          } else {
            this._router.navigate(['/home']);
          }

        } else {
          this.errorMessage = response.message;
          setTimeout(() => {
            this.errorMessage = "";
          }, 5000);
        }
      }
    });
  }

  ngOnDestroy(): void {
    if (this._securityServiceSubscription) this._securityServiceSubscription.unsubscribe();
  }
}
