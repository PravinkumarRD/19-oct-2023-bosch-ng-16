export class AuthResponse {
    success:boolean;
    message:string;
    role:string;
    token:string;
}
