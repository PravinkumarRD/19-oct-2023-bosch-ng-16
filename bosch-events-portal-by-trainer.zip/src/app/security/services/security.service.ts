import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { AuthResponse } from "../models/auth-response";
import { User } from "../models/user";

@Injectable()
export class SecurityService {
  constructor(private _httpClient: HttpClient) {

  }
  private _baseUrl: string = "http://localhost:9090/bosch";
  checkUserCredentials(user: User): Observable<AuthResponse> {
    return this._httpClient.post<AuthResponse>(`${this._baseUrl}/authentication`, user, {
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
}
