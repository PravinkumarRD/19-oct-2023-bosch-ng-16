import { DateInternationalizationPipe } from './date-internationalization.pipe';

describe('DateInternationalizationPipe', () => {
  it('create an instance', () => {
    const pipe = new DateInternationalizationPipe();
    expect(pipe).toBeTruthy();
  });
});
