import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DateInternationalizationPipe } from './pipes/date-internationalization.pipe';



@NgModule({
  declarations: [
    DateInternationalizationPipe
  ],
  imports: [
    CommonModule
  ],
  exports:[
    DateInternationalizationPipe
  ]
})
export class SharedModule { }
