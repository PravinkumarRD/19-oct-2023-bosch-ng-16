import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DateInternationalizationPipe } from './pipes/date-internationalization.pipe';

import { ResourceNotFoundComponent } from './components/resource-not-found/resource-not-found.component';



@NgModule({
  declarations: [
    DateInternationalizationPipe,
    ResourceNotFoundComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    DateInternationalizationPipe
  ]
})
export class SharedModule { }
