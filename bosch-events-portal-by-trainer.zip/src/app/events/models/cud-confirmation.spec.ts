import { CudConfirmation } from './cud-confirmation';

describe('CudConfirmation', () => {
  it('should create an instance', () => {
    expect(new CudConfirmation()).toBeTruthy();
  });
});
