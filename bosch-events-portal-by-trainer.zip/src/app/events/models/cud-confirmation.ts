export class CudConfirmation {
    acknowledged: boolean;
    insertedId: string;
}
