import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule,ReactiveFormsModule } from "@angular/forms";
import { NgxPaginationModule } from "ngx-pagination";
import { RouterModule } from "@angular/router";

import { SharedModule } from "../shared/shared.module";

import { EventsListComponent } from './components/events-list/events-list.component';
import { EventDetailsComponent } from './components/event-details/event-details.component';
import { RegisterEventComponent } from './components/register-event/register-event.component';

import { FilterEventsByNamePipe } from './pipes/filter-events-by-name.pipe';

import { EventsService } from './services/events.service';

import { EventsRoutingModule } from './events-routing.module';

@NgModule({
  declarations: [
    EventsListComponent,
    EventDetailsComponent,
    FilterEventsByNamePipe,
    RegisterEventComponent
  ],
  imports: [
    CommonModule,
    EventsRoutingModule,
    SharedModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule,
    RouterModule,
    ReactiveFormsModule
  ],
  exports:[
    EventsListComponent
  ],
  providers:[
    EventsService
  ]
})
export class EventsModule { }
