import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";
import { NgxPaginationModule } from "ngx-pagination";

import { SharedModule } from "../shared/shared.module";

import { EventsListComponent } from './components/events-list/events-list.component';
import { EventDetailsComponent } from './components/event-details/event-details.component';

import { FilterEventsByNamePipe } from './pipes/filter-events-by-name.pipe';

import { EventsService } from './services/events.service';

@NgModule({
  declarations: [
    EventsListComponent,
    EventDetailsComponent,
    FilterEventsByNamePipe
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule
  ],
  exports:[
    EventsListComponent
  ],
  providers:[
    EventsService
  ]
})
export class EventsModule { }
