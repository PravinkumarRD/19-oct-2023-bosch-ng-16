import { NgModule } from '@angular/core';
import { Routes,RouterModule } from "@angular/router";
import { EventsListComponent } from './components/events-list/events-list.component';
import { TokenGuard } from '../guards/token-guards';
import { RegisterEventComponent } from './components/register-event/register-event.component';
import { EventDetailsComponent } from './components/event-details/event-details.component';

const eventsRoutes:Routes=[
  {
    path:'',
    component:EventsListComponent,
    canActivate:[TokenGuard]
  },
  {
    path:'new',
    component:RegisterEventComponent,
    canActivate:[TokenGuard]
  },
  {
    path:':id',
    component:EventDetailsComponent,
    canActivate:[TokenGuard]
  }
];


@NgModule({
  imports: [
    RouterModule.forChild(eventsRoutes)
  ],
  exports:[
    RouterModule
  ]
})
export class EventsRoutingModule { }
