import { Component, OnDestroy } from '@angular/core';
import { Router } from "@angular/router";

import { RegisterEventModel } from "../../models/register-event-model";

import { EventsService } from "../../services/events.service";
import { Subscription } from 'rxjs';

@Component({
  selector: 'bosch-register-event',
  templateUrl: './register-event.component.html',
  styleUrls: ['./register-event.component.css']
})
export class RegisterEventComponent implements OnDestroy {
  constructor(private _eventsService: EventsService, private _router: Router) {

  }

  title: string = "Bosch Event Registration Form!";
  registerEventModel: RegisterEventModel = new RegisterEventModel();
  private _eventsServiceSubscription: Subscription;
  onNewEventSubmit(): void {
    this._eventsServiceSubscription = this._eventsService.registerNewEvent(this.registerEventModel.registrationForm.value).subscribe({
      next: confirmation => {
        if (confirmation.acknowledged === true) {
          this._router.navigate(['/events']);
        }
      }
    });
  }

  ngOnDestroy(): void {
    if (this._eventsServiceSubscription) this._eventsServiceSubscription.unsubscribe();
  }
}
