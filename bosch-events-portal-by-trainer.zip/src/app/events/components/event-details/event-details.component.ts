import { Component, Input } from '@angular/core';

import { Event } from "../../models/event";

@Component({
  selector: 'bosch-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent {
  title: string = "Details Of - ";
  @Input() event: Event;
}
