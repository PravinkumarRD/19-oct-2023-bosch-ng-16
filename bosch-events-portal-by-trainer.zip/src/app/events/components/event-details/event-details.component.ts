import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from "rxjs";
import { ActivatedRoute } from "@angular/router";

import { Event } from "../../models/event";

import { EventsService } from "../../services/events.service";

@Component({
  selector: 'bosch-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent implements OnInit, OnDestroy {
  constructor(private _activatedRoute: ActivatedRoute, private _eventsService: EventsService) {

  }

  title: string = "Details Of - ";
  //@Input() eventId: number;
  event: Event;
  private _eventsServiceSubscription: Subscription;
  ngOnInit(): void {
    let eventId = Number.parseInt(this._activatedRoute.snapshot.params['id']);
    this._eventsServiceSubscription = this._eventsService.getEventDetails(eventId).subscribe({
      next: data => this.event = data,
      error: err => console.log(err)
    });
  }
  ngOnDestroy(): void {
    if (this._eventsServiceSubscription) this._eventsServiceSubscription.unsubscribe();
  }
}
