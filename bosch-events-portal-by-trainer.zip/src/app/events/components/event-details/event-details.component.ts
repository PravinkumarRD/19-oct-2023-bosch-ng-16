import { Component, Input, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { Subscription } from "rxjs";

import { Event } from "../../models/event";

import { EventsService } from "../../services/events.service";

@Component({
  selector: 'bosch-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent implements OnChanges, OnDestroy {
  constructor(private _eventsService: EventsService) {

  }

  title: string = "Details Of - ";
  @Input() eventId: number;
  event: Event;
  private _eventsServiceSubscription: Subscription;
  ngOnChanges(simple: SimpleChanges): void {
    console.log(simple);
    this._eventsService.getEventDetails(this.eventId).subscribe({
      next: data => this.event = data
    });
  }
  ngOnDestroy(): void {
    if (this._eventsServiceSubscription) this._eventsServiceSubscription.unsubscribe();
  }
}
