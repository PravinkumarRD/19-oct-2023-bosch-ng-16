import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from "rxjs";

import { EventsService } from "../../services/events.service";

import { Event } from "../../models/event";

@Component({
  selector: 'bosch-events-list',
  templateUrl: './events-list.component.html',
  styleUrls: ['./events-list.component.css']
})
export class EventsListComponent implements OnInit, OnDestroy {
  constructor(private _eventsService: EventsService) {

  }

  title: string = "Welcome To Bosch Events List!";
  subTitle: string = "Published by Bosch Hr Team! India!";
  events: Observable<Event[]>;
  //events:Event[];
  currentPageNo: number = 1;
  totalItemsPerPage: number = 2;
  // selectedEvent: Event;
  selectedEventId:number;
  searchChars: string = "";
  private _eventsServiceSubscription: Subscription;
  ngOnInit(): void {
    this.events = this._eventsService.getAllEvents();
    // this._eventsServiceSubscription = this._eventsService.getAllEvents().subscribe({
    //   next: data => this.events = data,
    //   error: error => console.log(error)
    // });
  }

  onEventSelection(eventId: number): void {
    this.selectedEventId = eventId;
  }

  ngOnDestroy(): void {
    //if (this._eventsServiceSubscription) this._eventsServiceSubscription.unsubscribe();
  }
}
