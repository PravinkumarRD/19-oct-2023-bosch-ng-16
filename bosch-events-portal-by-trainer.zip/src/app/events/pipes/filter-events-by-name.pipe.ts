import { Pipe, PipeTransform } from '@angular/core';

import { Event } from "../models/event";

@Pipe({
  name: 'filterEventsByName'
})
export class FilterEventsByNamePipe implements PipeTransform {
  transform(value: Event[], ...args: string[]): Event[] {
    if (!value) return value;
    let filterChars: string = args[0] ? args[0] : '';
    return value.filter(e => e.eventName.toLocaleLowerCase().includes(filterChars.toLocaleLowerCase()));
  }

}
