import { FilterEventsByNamePipe } from './filter-events-by-name.pipe';

describe('FilterEventsByNamePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterEventsByNamePipe();
    expect(pipe).toBeTruthy();
  });
});
