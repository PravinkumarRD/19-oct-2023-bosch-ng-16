import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { Event } from "../models/event";
import { CudConfirmation } from '../models/cud-confirmation';

@Injectable()
export class EventsService {
  constructor(private _httpClient: HttpClient) {

  }
  private _baseUrl: string = "http://localhost:9090/api";
  getAllEvents(): Observable<Event[]> {
    return this._httpClient.get<Event[]>(`${this._baseUrl}/events`);
  }
  getEventDetails(eventId: number): Observable<Event> {
    return this._httpClient.get<Event>(`${this._baseUrl}/events/${eventId}`);
  }
  registerNewEvent(event: Event): Observable<CudConfirmation> {
    return this._httpClient.post<CudConfirmation>(`${this._baseUrl}/events`, event);
  }
}
