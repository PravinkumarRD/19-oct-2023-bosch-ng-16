import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Employee } from "../../models/employee";

@Component({
  selector: 'bosch-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent {
  title: string = "Details Of - ";
  @Input() employee: Employee;
  @Output() customEvent: EventEmitter<string> = new EventEmitter<string>();
  fireEvent():void{
    this.customEvent.emit(`Hello From Child Component with received Employee Name ${this.employee.employeeName}!`);
  }
}
