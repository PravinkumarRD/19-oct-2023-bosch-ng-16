import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeesListComponent } from './components/employees-list/employees-list.component';
import { EmployeeDetailsComponent } from './components/employee-details/employee-details.component';

import { EmployeesRoutingModule } from './employees-routing.module';


@NgModule({
  declarations: [
    EmployeesListComponent,
    EmployeeDetailsComponent
  ],
  imports: [
    CommonModule,
    EmployeesRoutingModule
  ],
  exports:[
    EmployeesListComponent
  ]
})
export class EmployeesModule { }
