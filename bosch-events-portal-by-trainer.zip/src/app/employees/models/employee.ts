export class Employee {
    employeeId: number;
    employeeName:string;
    address:string;
    city:string;
    country:string;
    email:string;
    phone:string;
    zipcode:number;
    joiningDate:Date;
    skillSets:string;
    avatar:string;
}
