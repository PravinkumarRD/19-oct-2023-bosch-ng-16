import { TokenGuards } from './token-guards';

describe('TokenGuards', () => {
  it('should create an instance', () => {
    expect(new TokenGuards()).toBeTruthy();
  });
});
