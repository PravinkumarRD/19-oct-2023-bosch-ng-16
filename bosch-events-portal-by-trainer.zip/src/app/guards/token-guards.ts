import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, RouterStateSnapshot, Router } from '@angular/router';

export const TokenGuard: CanActivateFn = (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
) => {
    const _router = inject(Router);
    const token = sessionStorage.getItem("token");
    if (token) {
        return true;
    } else {
        _router.navigate(['/login'], {
            queryParams: {
                'returnurl': state.url
            }
        });
        return false;
    }
}