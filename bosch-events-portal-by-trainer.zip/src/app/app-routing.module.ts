import { NgModule } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";

import { DefaultComponent } from './home/default/default.component';
import { HomeComponent } from './home/home/home.component';

import { ResourceNotFoundComponent } from './shared/components/resource-not-found/resource-not-found.component';
import { LoginComponent } from './security/components/login/login.component';


const rootRoutes: Routes = [
  {
    path: '',
    component: DefaultComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'employees',
    loadChildren: () => import("./employees/employees.module").then(m => m.EmployeesModule)
  },
  {
    path: 'events',
    loadChildren: () => import("./events/events.module").then(m => m.EventsModule)
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '**',
    component: ResourceNotFoundComponent
  }
];


@NgModule({
  imports: [
    RouterModule.forRoot(rootRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
