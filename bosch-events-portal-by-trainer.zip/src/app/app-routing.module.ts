import { NgModule } from '@angular/core';
import { Routes, RouterModule } from "@angular/router";

import { DefaultComponent } from './home/default/default.component';
import { HomeComponent } from './home/home/home.component';
import { EmployeesListComponent } from './employees/components/employees-list/employees-list.component';
import { EventsListComponent } from './events/components/events-list/events-list.component';

const rootRoutes:Routes=[
  {
    path:'',
    component:DefaultComponent
  },
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'employees',
    component:EmployeesListComponent
  },
  {
    path:'events',
    component:EventsListComponent
  }
];


@NgModule({
  imports: [
    RouterModule.forRoot(rootRoutes)
  ],
  exports:[
    RouterModule
  ]
})
export class AppRoutingModule { }
