import { Component } from '@angular/core';

@Component({
  selector: 'bosch-default',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.css']
})
export class DefaultComponent {

}
