const { authenticateUser } = require('../dal/security-dal');

async function checkCredentials(user) {
    return await authenticateUser(user);
}

module.exports = {
    checkCredentials
}