const { getAllEvents, getEventDetails, insertNewEvent } = require('../dal/events-dal');

async function getAllBoschEvents() {
    return await getAllEvents();
}
async function getBoschEventDetails(id) {
    return await getEventDetails(id);
}
async function registerNewEvent(event) {
    return await insertNewEvent(event);
}

module.exports = {
    getAllBoschEvents,
    getBoschEventDetails,
    registerNewEvent
}