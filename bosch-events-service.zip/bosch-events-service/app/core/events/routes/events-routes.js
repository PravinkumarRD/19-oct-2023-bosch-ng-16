//Declare all children routes of Employees feature
const express = require('express');
const { tokenAuthorization } = require('../../../middleware/authorization');

const { getAllBoschEvents,getBoschEventDetails, registerNewEvent } = require('../services/events-service');

const eventsRoutes = express.Router();

//eventsRoutes.use(tokenAuthorization);

eventsRoutes.get('/', async (request, response) => {
    try {
        response.json(await getAllBoschEvents());
    } catch (error) {
        response.json({
            success: false,
            message: error.message
        });
    }
});
eventsRoutes.get('/:eventId', async (request, response) => {
    try {
        response.json(await getBoschEventDetails(Number.parseInt(request.params.eventId)));
    } catch (error) {
        response.json({
            success: false,
            message: error.message
        });
    }
});
eventsRoutes.post('/', async (request, response) => {
    try {
        response.json(await registerNewEvent(request.body)).status(201);
    } catch (error) {
        response.json({
            success: false,
            message: error.message
        });
    }
});
module.exports = eventsRoutes;